<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
  <head>
    <title><?php echo e(env('APP_NAME','FloraSyria')); ?> | <?php echo $__env->yieldContent('title'); ?> </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="<?php echo e(setting('site.description')); ?>">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/flaticon.css')); ?>">
    <?php if(App::getLocale()=="ar"): ?>{
      <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    }<?php else: ?>{
      <link rel="stylesheet" href="<?php echo e(asset('css/enstyle.css')); ?>">
    }
    <?php endif; ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    
    <link rel="apple-touch-icon"  href="<?php echo e(setting('site.logo')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(setting('site.logo')); ?>">


  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light fixed-top" id="ftco-navbar">
        <a class="navbar-brand" href="#">
            <img src="<?php echo e(asset('images/logo-white.png')); ?>" width="90" height="50" alt="FloraSyria">
        </a> 

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	    </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">

	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item <?php echo e(Request::path()=='/' ? 'active' : ''); ?>"><a href="/" class="nav-link pl-0"><?php echo e(__('Home')); ?></a></li>
            <li class="nav-item <?php echo e(Request::path()=='about' ? 'active' : ''); ?>"><a href="<?php echo e(route('about',app()->getLocale())); ?>" class="nav-link"><?php echo e(__('founder')); ?></a></li>
            <li class="nav-item <?php echo e(Request::path()=='topography' ? 'active' : ''); ?> dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php echo e(__('syria')); ?> 
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="<?php echo e(route('topography',app()->getLocale())); ?> "><?php echo e(__('Climate and Topography')); ?></a>
                <a class="dropdown-item" href="<?php echo e(route('soil',app()->getLocale())); ?> "><?php echo e(__('soil')); ?></a>
                <a class="dropdown-item" href="<?php echo e(route('planetBio',app()->getLocale())); ?> "> <?php echo e(__('Plant Biodiversity')); ?></a>
                <a class="dropdown-item" href="<?php echo e(route('flora',app()->getLocale())); ?> "> <?php echo e(__('Flora')); ?></a>
              </div>
            </li>
            <li class="nav-item <?php echo e(Request::path()=='team' ? 'active' : ''); ?>"><a href="<?php echo e(route('team',app()->getLocale())); ?>" class="nav-link"> <?php echo e(__('team')); ?></a></li>
            <li class="nav-item <?php echo e(Request::path()=='publications' ? 'active' : ''); ?>"><a href="<?php echo e(route('publications',app()->getLocale())); ?>" class="nav-link"><?php echo e(__('publications')); ?></a></li>
	        	<li class="nav-item <?php echo e(Request::path()=='advsearch' ? 'active' : ''); ?>"><a href="<?php echo e(route('search',app()->getLocale())); ?> " class="nav-link"><?php echo e(__('Search')); ?></a></li>
	          <li class="nav-item <?php echo e(Request::path()=='contact' ? 'active' : ''); ?>"><a href="<?php echo e(route('contact',app()->getLocale())); ?> " class="nav-link"><?php echo e(__('contact')); ?></a></li>
	        </ul>
	      </div>

	  </nav>
    <!-- END nav -->

    <?php echo $__env->yieldContent('content'); ?>

    <footer class="ftco-footer ftco-bg-dark ftco-section">
        <div class="container">

          <div class="row">
            <div class="col-md-2">
              <div class="float-right">

                <a href="<?php echo e(route('changelang', ['lang' => 'ar'])); ?>"> AR <img src="<?php echo e(asset('images/ar.png')); ?>" alt="arabic"> </a> | <a href="<?php echo e(route('changelang', ['lang' => 'en'])); ?>"><img src="<?php echo e(asset('images/en.png')); ?>" alt="arabic"> EN </a>
              </div>
            </div>
            
            <div class="col-md-10 text-center">
  
              <p>
    &copy;<?php echo e(__('All rights reserved | This Website is made  by')); ?> <a href="#" target="_blank">FloraSyria</a> <script>document.write(new Date().getFullYear());</script>
   </p>
            </div>

          </div>
        </div>
      </footer>
      
    
  
    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>
  
  
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-migrate-3.0.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.easing.1.3.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.stellar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.animateNumber.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scrollax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>

    <?php echo $__env->yieldContent('script'); ?>
      
    </body>
  </html><?php /**PATH C:\wamp64\www\florasyria\site\resources\views/layout/layout.blade.php ENDPATH**/ ?>