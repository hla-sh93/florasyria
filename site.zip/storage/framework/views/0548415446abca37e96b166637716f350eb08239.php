<?php $__env->startSection('title'); ?> Publications  <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

    <section class="hero-wrap hero-wrap-2" style="background-image: url('/images/bg_1.jpg');">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
              <h1 class="mt-2 bread">Publications</h1>
            </div>
          </div>
        </div>
      </section>

    <section class="ftco-section">
        <div class="container">
            <div class="col-md-12 ftco-animate">
                <h2 class="mb-4"><?php echo e(__('Published Articles')); ?></h2>
                <p>هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.
                    إذا كنت تحتاج إلى عدد أكبر</p>
                </div> <br>
                <div class="col-md-10 offset-md-1 ftco-animate">
                <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- Card No1-->
              <?php $file = (json_decode($item->document))[0]->download_link; ?>
              <a href="<?php echo e(Voyager::image( $file )); ?>" class="card mt-4">
                  <div class="card-body">
                      <div class="row">
                          <div class="col-md-2 col-sm-6">
                              <img src="<?php echo e(asset('images/attachement.png')); ?>" alt="" class="card_img" width="100px">
                          </div>
                          <div class="col-md-10 col-sm-6">
                              <div class="row">
                                  <div class="col-md-12">
                                      <h5 class="card-title blue card_title mr-0 mt-0"><?php echo e($item->name); ?></h5>
                                  </div>
                              </div>
                              <div class="row">
                                  <div class="col-md-12">
                                      <p class="mb-0 pb-0"><?php echo e($item->desc); ?></p>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </a>
              <!-- End Card No1-->
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\florasyria\site\resources\views/publications.blade.php ENDPATH**/ ?>