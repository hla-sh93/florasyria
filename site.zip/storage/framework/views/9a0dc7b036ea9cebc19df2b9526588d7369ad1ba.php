<?php $__env->startSection('title'); ?> Founder <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

    <section class="hero-wrap hero-wrap-2" style="background-image: url('/images/bg_1.jpg');">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
                  <h1 class="mt-2 bread"> Founder </h1>
            </div>
          </div>
        </div>
      </section>

    <section class="ftco-section">
        <div class="container">
            <div class="row d-flex">
              <?php $__currentLoopData = $founder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-9 wrap-about pr-md-4 ftco-animate">
                    <h2 class="mb-4">              
                      <?php if(App::getLocale()=="ar"): ?>
                      <?php echo e($object->ar_name); ?>

                      <?php else: ?>
                      <?php echo e($object->en_name); ?>

                      <?php endif; ?>
                    </h2>
                    <p>
                      <?php if(App::getLocale()=="ar"): ?>
                      <?php echo $object->ar_description; ?>

                      <?php else: ?>
                      <?php echo $object->en_description; ?>

                      <?php endif; ?>
                    </p>               
                    </div>
                <div class="col-md-3">
                  <img src="<?php echo e(Voyager::image($object->img)); ?>" alt="<?php echo e($object->en_name); ?>" width="100%" class="mt-md-5 mb-md-3">
                  <?php $file = (json_decode($object->cv_file))[0]->download_link; ?>
                  <a href="<?php echo e(Voyager::image( $file )); ?>" target="_blank">
                    <button class="btn btn-primary py-2 px-5"> 
                    <?php echo e(__('Curriculum Vitae')); ?>

                  </button>
                </a>
                </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\florasyria\site\resources\views/about.blade.php ENDPATH**/ ?>