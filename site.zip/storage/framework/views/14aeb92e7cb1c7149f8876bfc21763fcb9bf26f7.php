<?php $__env->startSection('title'); ?> climate and Topography <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('/images/bg_1.jpg');">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
              <h1 class="mb-2 bread">climate and Topography</h1>
            </div>
          </div>
        </div>
      </section>

		<section class="ftco-section ">
			<div class="container">
				<div class="row justify-content-center mb-2">
					<div class="col-md-12 ftco-animate">
                    <h2 class="mb-4 text-center heading-section"><?php echo e(__('Climate and Topography')); ?></h2>
					</div>
				</div>
				<div class="row">
				<div class="col-md-9">
					<p class="text-justify">
                        <?php $__currentLoopData = $topography; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(App::getLocale()=="ar"): ?>
                            <?php echo e($itme->ar_desc); ?>

                        <?php else: ?>
                            <?php echo e($itme->en_desc); ?>

                        
                        <?php endif; ?>	
                    
                    </p>
                </div>
                <div class="col-md-3">
                    <img src="<?php echo e(Voyager::image($itme->file)); ?>" alt="climateSyria" width="300px" height="">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
				</div>
			</div>
		</section>

	<section class="ftco-section bg-alic">
        <div class="container">
            <div class="row justify-content-center mb-2">
                <div class="col-md-12 ftco-animate">
                    <h2 class="mb-4 text-center heading-section"><?php echo e(__('Rainfall')); ?></h2>
				</div>
			</div>
			<div class="row">
                <div class="col-md-12">
                    <p class="text-center">
                        <?php $__currentLoopData = $rainfall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(App::getLocale()=="ar"): ?>
                            <?php echo e($itme->ar_desc); ?>

                        <?php else: ?>
                            <?php echo e($itme->en_desc); ?>

                        
                        <?php endif; ?>	
                      
                    </p>
                </div>
                <?php $file = (json_decode($itme->file))[0]->download_link; ?>
                <a href="<?php echo e(Voyager::image( $file )); ?>" target="_blank" class="mx-auto d-block">
                <button class="btn btn-primary py-3 px-5 mx-auto d-block"><?php echo e(__('attachement')); ?></button>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
        </div>
    </section>

    <section class="ftco-section ">
        <div class="container">
            <div class="row justify-content-center mb-2">
                <div class="col-md-12 ftco-animate">
                    <h2 class="mb-4 text-center heading-section"><?php echo e(__('Temperature')); ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <p class="text-center">
                        <?php $__currentLoopData = $temperature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(App::getLocale()=="ar"): ?>
                            <?php echo e($itme->ar_desc); ?>

                        <?php else: ?>
                            <?php echo e($itme->en_desc); ?>

                        
                        <?php endif; ?>	
                      
                    </p>
                </div>
                <?php $file = (json_decode($itme->file))[0]->download_link; ?>
                <a href="<?php echo e(Voyager::image( $file )); ?>" target="_blank" class="mx-auto d-block">
                <button class="btn btn-primary py-3 px-5 mx-auto d-block"><?php echo e(__('attachement')); ?></button>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
        </div>
    </section>

    <section class="ftco-section bg-alic">
        <div class="container">
            <div class="row justify-content-center mb-2">
                <div class="col-md-12 ftco-animate">
                    <h2 class="mb-4 text-center heading-section"><?php echo e(__('Evaporation')); ?></h2>
				</div>
			</div>
			<div class="row">
                <div class="col-md-12">
                    <p class="text-center">
                        <?php $__currentLoopData = $evaporation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(App::getLocale()=="ar"): ?>
                            <?php echo e($itme->ar_desc); ?>

                        <?php else: ?>
                            <?php echo e($itme->en_desc); ?>

                        
                        <?php endif; ?>	
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </p>
                </div>
			</div>
        </div>
    </section>

    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center mb-2">
                <div class="col-md-12 ftco-animate">
                    <h2 class="mb-4 text-center heading-section"><?php echo e(__('Bio-climatic Subdivision')); ?></h2>
				</div>
			</div>
			<div class="row">
                <div class="col-md-12">
                    <p class="text-center">
                        <?php $__currentLoopData = $bioclimatic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(App::getLocale()=="ar"): ?>
                            <?php echo e($itme->ar_desc); ?>

                        <?php else: ?>
                            <?php echo e($itme->en_desc); ?>

                        
                        <?php endif; ?>	
                     
                    </p>
                </div>
                <?php $file = (json_decode($itme->file))[0]->download_link; ?>
                <a href="<?php echo e(Voyager::image( $file )); ?>" target="_blank" class="mx-auto d-block">
                <button class="btn btn-primary py-3 px-5 mx-auto d-block"><?php echo e(__('attachement')); ?></button>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div> <br> <br>
            <div class="row">
                <div class="col-md-12">
                    <?php $__currentLoopData = $bioclimatic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(App::getLocale()=="ar"): ?>
                        <?php echo $itme->ar_subdivision; ?>

                    <?php else: ?>
                        <?php echo $itme->en_subdivision; ?>

                    
                    <?php endif; ?>	
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
            </div>
        </div>
    </section>


	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\florasyria\site\resources\views/topography.blade.php ENDPATH**/ ?>