<?php $__env->startSection('title','Advanced Search'); ?>
    
    <?php $__env->startSection('content'); ?>

    <section class="hero-wrap hero-wrap-2" style="background-image: url('/images/bg_1.jpg');">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
              <h1 class="mb-2 bread"> FSOL Advanced Search</h1>
            </div>
          </div>
        </div>
      </section>

      <section class="ftco-section contact-section">
        <div class="container">
          <div class="row block-9 mb-5">
            <div class="col-md-12 mb-md-5">
              <form action="advsearch" method="POST" class="bg-light p-5">
                <?php echo csrf_field(); ?>
                <div class="form-row">
                   <div class="col">
                    <div class="form-group">
                        <label for="flowring-start"><?php echo e(__('Start Flowering')); ?></label>
                        <select class="form-control" id="flowring-start" name="flowring-start">
                          <option value=""> choose One ..</option>
                          <?php for($i=1;$i<=12;$i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                          <?php endfor; ?>
                        </select>
                      </div>
                   </div>
                   <div class="col">
                    <div class="form-group">
                        <label for="flowring-end"><?php echo e(__('End Flowering')); ?></label>
                        <select class="form-control" id="flowring-end" name="flowring-end">
                          <option value=""> choose One ..</option>
                          <?php for($i=1;$i<=12;$i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                          <?php endfor; ?>
                        </select>
                      </div>
                   </div>
                   <div class="col">
                    <div class="form-group">
                        <label for="life"><?php echo e(__('life')); ?></label>
                        <select class="form-control" id="life" name="life">
                          <option value=""> choose One ..</option>
                          <?php $__currentLoopData = $lives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $life): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($life->id); ?>"><?php echo e($life->ar_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                   </div>
                </div>

                <div class="form-row">
                    <div class="col">
                     <div class="form-group">
                         <label for="econ_value"><?php echo e(__('Economic Value')); ?></label>
                         <select class="form-control" id="econ_value" name="econ_value">
                          <option value=""> choose One ..</option>
                          <?php $__currentLoopData = $ecoValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->ar_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                       </div>
                    </div>

                    <div class="col">
                     <div class="form-group">
                         <label for="areas"><?php echo e(__('Areas')); ?></label>
                         <select class="form-control" id="areas" name="areas">
                          <option value=""> choose One ..</option>
                          <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                       </div>
                    </div>
                  </div>
                  
                    <div class="form-row">
                      <div class="col">
                        <div class="form-group">
                            <label for="governorates"><?php echo e(__('Syrian Governorate')); ?></label>
                            <select class="form-control dynamic" id="governorates" name="governorates" data-dependent="cities">
                              <option value=""> choose One ..</option>
                              <?php $__currentLoopData = $govs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                       </div>
                       <div class="col">
                        <div class="form-group">
                            <label for="cities"><?php echo e(__('Syrian Cities')); ?></label>
                            <select class="form-control dynamic" id="cities" name="cities" data-dependent="villages">

                            </select>
                          </div>
                       </div>
                       <div class="col">
                        <div class="form-group">
                            <label for="villages"><?php echo e(__('Syrian Villages')); ?></label>
                            <select class="form-control" id="villages" name="villages">

                            </select>
                          </div>
                       </div>
                    </div>
                
                 <div class="form-group">
                    <input type="submit" value="<?php echo e(__('Search')); ?>" class="btn btn-primary py-2 px-5 float-left">
                  </div>
              </form>
            
            </div>
          </div>

            <div class="row d-flex">
                
              <?php $__currentLoopData = $species; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <!-- Card No1-->
                  <div class="col-md-6  ftco-animate">
                  <a href="<?php echo e(route('details',[app()->getLocale(), $item->id] )); ?>" class="card mt-4">
                      <div class="card-body">
                          <div class="row">
                              <div class="col-md-4 col-sm-6">
                                  <img src="<?php echo e(Voyager::image( $item->img )); ?>" alt="<?php echo e($item->Gname); ?> <?php echo e($item->name); ?>" class=" mx-auto d-block" width="100px">
                              </div>
                              <div class="col-md-8 col-sm-6">
                                  <div class="row">
                                      <div class="col-md-12">
                                          <h5 class="card-title blue card_title mr-0 mt-0"><?php echo e($item->Gname); ?> <?php echo e($item->name); ?></h5>
                                      </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-md-12">
                                          <p><?php echo e(substr($item->desc,0,100 )); ?> ...</p>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </a>
                </div>
                  <!-- End Card No1-->
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
            </div>
        </div>
      </section>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
          $(".dynamic").change(function(){
            if($(this).val() !=""){
              var select=$(this).attr("id");
              var value=$(this).val();
              var dependent=$(this).data("dependent");
              var _token=$('input[name="_token"]').val();
              
              $.ajax({
                url: "advsearchfetch",
                method: "GET",
                data: {select:select,value:value,dependent:dependent},
                success: function(result){
                  $("#"+dependent).html(result);
                }
              });
            }
          });

          $('#governorates').change(function(){
              $('#cities').val('');
              $('#villages').val('');
          });

        $('#cities').change(function(){
          $('#villages').val('');
          });
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\florasyria\site\resources\views/advsearch.blade.php ENDPATH**/ ?>