<?php $__env->startSection('title'); ?> Team <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

    <section class="hero-wrap hero-wrap-2" style="background-image: url('/images/bg_1.jpg');">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
              <h1 class="mt-2 bread">OUR Team</h1>
            </div>
          </div>
        </div>
      </section>

    <section class="ftco-section">
        <div class="container">
            <div class="row d-flex">

                <div class="col-md-12 wrap-about pr-md-4 ftco-animate">
                    <h2 class="mb-4">فريق العمل</h2>
                    <p>هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.
                        إذا كنت تحتاج إلى عدد أكبر</p>
                    <div class="row mt-5">
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="col-lg-6">
                        <a  href="<?php echo e(route('profile',[app()->getLocale(), $team->id] )); ?>">
                            <div class="services text-center">
                                <div class="icon mt-2 d-flex justify-content-center align-items-center">
                                    <?php 
                                    if(Voyager::image($team->img) =="") {  ?>
                                    <img src="<?php echo e(asset('images/user.jpg')); ?>" alt="<?php echo e($team->en_name); ?>" class="rounded-circle user-img" >
                                    <?php 
                                     } else { ?>
                                     
                                   <img src="<?php echo e(Voyager::image($team->img)); ?>" alt="<?php echo e($team->en_name); ?>" class="rounded-circle user-img" >
                               <?php }?>
                                </div>
                                <div class="text media-body">
                                    <h3>
                                        <?php if(App::getLocale()=="ar"): ?>
                                        <?php echo e($team->ar_name); ?>

                                    <?php else: ?>
                                        <?php echo e($team->en_name); ?>

                                    
                                    <?php endif; ?>
                                    </h3>
                                    <p>
                                        <?php if(App::getLocale()=="ar"): ?>
                                            <?php echo e($team->ar_jobTitle); ?>

                                        <?php else: ?>
                                            <?php echo e($team->en_jobTitle); ?>

                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </a> 
                        </div>
                      
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\florasyria\site\resources\views/team.blade.php ENDPATH**/ ?>