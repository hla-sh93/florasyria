<?php $__env->startComponent('mail::message'); ?>

<strong> Name: </strong> <?php echo e($data['contact_name']); ?>

<br>
<strong> Email: </strong> <?php echo e($data['contact_email']); ?>

<br>
<strong> Subject: </strong> <?php echo e($data['contact_subject']); ?>

<br>
<strong> Message: </strong> <?php echo e($data['contact_message']); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\florasyria\site\resources\views/emails/contact/contact-form.blade.php ENDPATH**/ ?>