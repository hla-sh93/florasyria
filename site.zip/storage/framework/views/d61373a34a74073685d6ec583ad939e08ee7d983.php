<?php $__env->startSection('title'); ?> BioDiversity <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('/images/bg_1.jpg');">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
              <h1 class="mb-2 bread">Planet BioDiversity</h1>
            </div>
          </div>
        </div>
      </section>

    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center mb-2">
                <div class="col-md-12 ftco-animate">
                <h2 class="mb-4 text-center heading-section"><?php echo e(__('Vegetation zones')); ?></h2>
				</div>
			</div>
 <br> <br>
            <div class="row">
                <div class="col-md-12">

                 <?php $__currentLoopData = $bio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                <h4>
                <?php if(App::getLocale()=="ar"): ?>
                    <?php echo e($object->ar_name); ?>

                <?php else: ?>
                    <?php echo e($object->en_name); ?>

                
                <?php endif; ?>
                </h4>   
                    <div class="row">
                        <div class="col-md-9">
                            <p class="text-justify">
                            <?php if(App::getLocale()=="ar"): ?>
                                <?php echo $object->ar_desc; ?>

                            <?php else: ?>
                                <?php echo $object->en_desc; ?>

                            
                            <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-3">
                            <img src="<?php echo e(Voyager::image($object->img)); ?>" alt="<?php echo e($object->en_name); ?>" width="300px" height="300px">
                        </div>
                    </div> <hr> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>


	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\florasyria\site\resources\views/planetBio.blade.php ENDPATH**/ ?>