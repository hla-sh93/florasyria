<?php $__currentLoopData = $spe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$item->species->name .' '.$item->name); ?>
    <?php $__env->startSection('content'); ?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('/images/bg_1.jpg');">
        <div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
              <h1 class="mb-2 bread"><?php echo e($item->species->name); ?> <?php echo e($item->name); ?></h1>
            </div>
          </div>
        </div>
      </section>

    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center mb-2">
                <div class="col-md-12 ftco-animate">
                    <h2 class="mb-4 text-center heading-section"><?php echo e($item->species->name); ?> <?php echo e($item->name); ?></h2>
				</div>
			</div>
			<div class="row">
                <div class="col-md-9">
                    <p class="text-justify">
                        <?php echo e($item->desc); ?>

                    </p>
                    <p class="text-justify">
                        <?php if( $item->reference_id !=""): ?>
                        Reference:
                        <a href="<?php echo e($item->reference->source); ?>" target="_blank"><?php echo e($item->reference->title); ?></a>
                        <?php endif; ?> 
                    </p>
                </div>
                <div class="col-md-3">
                    <img src="<?php echo e(Voyager::image($item->img)); ?>" alt="<?php echo e($item->species->name); ?>" height="150px">
                </div>
            </div> <br> <br>
            <div class="row">
                <div class="col-md-12">

                    <div class="row">
                        <div class="col-md-6">
                            <h4>الاسم العلمي</h4>
                            <p class="text-justify"> <?php echo e($item->species->name); ?> <?php echo e($item->name); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h4>الاسم المحلي</h4>
                            <p class="text-justify"> <?php echo e($item->local); ?></p>
                        </div>
                    </div> <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <h4>لون الزهرة</h4>
                            <p class="text-justify"> <?php echo e($item->color); ?> </p>
                        </div>
                        <div class="col-md-6">
                            <h4>المميزات</h4>
                            <p class="text-justify"> <?php echo e($item->characterization); ?></p>
                        </div>
                    </div> <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <h4>البيئة</h4>
                            <p class="text-justify"><?php echo e($item->habitat); ?> </p>
                        </div>
                        <div class="col-md-6">
                            <h4>دورة الحياة</h4>
                            <p class="text-justify"> 
                                <?php if( $item->life1_id !=""): ?>
                                <?php echo e($item->life_1->ar_name); ?>

                                <?php endif; ?> 
                                <?php if( $item->life2_id !=""): ?>
                                , <?php echo e($item->life_2->ar_name); ?>

                                <?php endif; ?>
                                
                            </p>
                        </div>
                    </div> <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <h4>القيمة الاقتصادية</h4>
                            <p class="text-justify">
                                <?php if( $item->ecValue_id !=""): ?>
                                <?php echo e($item->ecovalue->ar_name); ?>

                                <?php endif; ?>                                
                            </p>
                        </div>
                        <div class="col-md-6">
                            <h4>الانتماء الجغرافي </h4>
                            <p class="text-justify">
                                <?php if( $item->area_id !=""): ?>
                                <?php echo e($item->area->name); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                    </div> <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <h4>التوزع في سورية حسب المناطق</h4>
                            <p class="text-justify">
                                <?php if( $item->location_id !=""): ?>
                                <?php echo e($item->location->name); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <h4>أشهر الإزهار</h4>
                            <p class="text-justify">
                                <?php for($i=$item->start_flower; $i<=$item->end_flower;$i++): ?>
                                <?php echo e($i.' '); ?>

                                <?php endfor; ?>
                            </p>
                        </div>
                    </div> <hr>

                </div>
            </div>
        </div>
    </section>


    <?php $__env->stopSection(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\florasyria\site\resources\views/details.blade.php ENDPATH**/ ?>