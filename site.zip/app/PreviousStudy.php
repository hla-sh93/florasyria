<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PreviousStudy extends Model
{
    protected $table = 'previous_studies';
    public $timestamps = false;
}
