<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Evaporation extends Model
{
    protected $table = 'evaporation';
    public $timestamps = false;
}
