<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FloranEndemism extends Model
{
    protected $table = 'floran_endemism';
    public $timestamps = false;
}
