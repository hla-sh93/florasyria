<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Soil extends Model
{
    protected $table = 'soil';
    public $timestamps = false;
}
