<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HowToHelp extends Model
{
    protected $table = 'how_to_help';
    public $timestamps = false;
}
