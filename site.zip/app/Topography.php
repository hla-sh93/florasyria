<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Topography extends Model
{
    protected $table = 'topography';
    public $timestamps = false;
}
