<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EcoValue extends Model
{
    protected $table = 'eco_value';
    public $timestamps = false;
}
