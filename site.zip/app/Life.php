<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Life extends Model
{
    protected $table = 'life';
    public $timestamps = false;
}
