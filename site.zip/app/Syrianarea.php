<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Syrianarea extends Model
{
    protected $table = 'locations';
    public $timestamps = false;
}
