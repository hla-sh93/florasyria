<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlanetBiodiversity extends Model
{
    protected $table = 'planet_biodiversity';
    public $timestamps = false;
}
