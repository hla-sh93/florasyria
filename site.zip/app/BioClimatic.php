<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BioClimatic extends Model
{
    protected $table = 'bio_climatic';
    public $timestamps = false;
}
